SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

DELIMITER $$

CREATE PROCEDURE `Login` (`Nickname` VARCHAR(30), `UserPass` VARCHAR(35))
BEGIN
    SELECT Users.UserId, Users.Nickname, Users.Priority 
    FROM Users
    WHERE Users.Nickname = Nickname AND Users.UserPswrd = UserPass;
END$$
DELIMITER ;
CREATE PROCEDURE `Messages` (`User_Id` INT)
BEGIN
SELECT 
	comments.ComId,
    comments.UserId,
    comments.Parent,
    comments.TypePar,
    comments.Textcom,
    comments.DatePubl
FROM comments,
(SELECT `Parent`,`TypePar` FROM `search` WHERE UserId = User_Id AND TypePar IN(1,2)) AS Posts
WHERE comments.Parent = Posts.Parent AND comments.TypePar = Posts.TypePar AND UserId !=User_Id AND issetMark(comments.Parent,0,User_Id,2)=0
UNION
SELECT 
	comments.ComId,
    comments.UserId,
    comments.Parent,
    comments.TypePar,
    comments.Textcom,
    comments.DatePubl
FROM comments,
(SELECT ComId FROM comments WHERE UserId=User_Id) AS MCom
WHERE comments.Parent = MCom.ComId AND comments.TypePar = 0 AND comments.ComId !=User_Id AND issetMark(comments.Parent,0,User_Id,2)=0;
END$$
DELIMITER ;

CREATE PROCEDURE `Users_ChangeNick` (`Oldnick` VARCHAR(30), `Newnick` VARCHAR(30), `UserPass` VARCHAR(35))
BEGIN
    DECLARE Usr INT DEFAULT 0;
    DECLARE UsrExist INT DEFAULT 0;
    SELECT count(`UserId`) INTO Usr FROM Users WHERE `Nickname` = Oldnick AND `UserPswrd` = UserPass;
    SELECT count(`UserId`) INTO UsrExist FROM Users WHERE `Nickname` = Newnick;
    IF UsrExist = 0 THEN
    BEGIN
	IF Usr = 1 THEN
	BEGIN
	    UPDATE Users SET Nickname = Newnick WHERE `Nickname` = Oldnick;
	    SELECT 0;
	END;
	ELSE SELECT 1;
	END IF;
    END;
    ELSE SELECT 2;
    END IF;
END$$
DELIMITER ;
CREATE PROCEDURE `Users_ChangePassword` (IN `Id` INT, IN `UserPass` VARCHAR(35), IN `NewPass` VARCHAR(35))
BEGIN
    DECLARE Usr INT DEFAULT 0;
    SELECT count(Users.UserId) INTO Usr FROM Users WHERE Users.UserId = Id AND Users.UserPswrd = UserPass;
    IF Usr = 1 THEN
    BEGIN
        UPDATE Users SET UserPswrd = NewPass WHERE UserId = Id;
        SELECT 0;
    END;
    ELSE SELECT 1;
    END IF;
END$$

--
-- Функции
--
DELIMITER $$
CREATE FUNCTION `ChildComments` (`parentId` INT, `parentType` INT) RETURNS INT
BEGIN 
  DECLARE CN INT DEFAULT 0;
  SELECT COUNT(comments.ComId) INTO CN FROM comments 
  WHERE `TypePar`=parentType and `Parent`= parentId;
  RETURN CN;
END$$
DELIMITER ;

DELIMITER $$
CREATE FUNCTION `getMark` (`parentId` INT, `parentType` INT, `markType` INT) RETURNS INT
BEGIN 
  DECLARE MR INT DEFAULT 0;
  SELECT COUNT(Marks.Mark) INTO MR FROM Marks 
  WHERE `TypePar`=parentType AND `Parent`= parentId AND `Mark` = markType;
  RETURN MR;
END$$
DELIMITER ;

DELIMITER $$
CREATE FUNCTION `issetMark` (`parentId` INT, `parentType` INT, `UserId` INT, `TypeMark` INT) RETURNS INT(11)
BEGIN 
  DECLARE MR INT DEFAULT 0;
  SELECT count(Marks.`Mark`) INTO MR FROM Marks WHERE 
    Marks.`Mark` = TypeMark AND
    Marks.`UserId` = UserId AND
    Marks.`Parent` = parentId AND
    Marks.`TypePar` = parentType;
  RETURN MR;
END$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--

CREATE TABLE `articles` (
  `ArtId` int(10) NOT NULL,
  `UserId` int(10) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `ArtType` tinyint(4) NOT NULL DEFAULT 0,
  `Name` varchar(40) NOT NULL,
  `Tags` varchar(30) DEFAULT NULL,
  `DatePubl` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB

-- --------------------------------------------------------

--
-- Дублирующая структура для представления `articlesinfo`
-- (См. Ниже фактическое представление)
--

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `ComId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `Parent` int(11) NOT NULL,
  `Textcom` varchar(255) DEFAULT NULL,
  `TypePar` tinyint(4) NOT NULL,
  `DatePubl` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Триггеры `comments`
--
DELIMITER $$
CREATE TRIGGER `addComment` BEFORE INSERT ON `comments` FOR EACH ROW BEGIN
    DECLARE n INT DEFAULT 0;
    CASE NEW.TypePar
	WHEN 0 THEN 
	    SELECT COUNT(Comments.ComId) INTO n FROM Comments WHERE Comments.ComId = NEW.Parent;
	WHEN 1 THEN 
	    SELECT COUNT(Articles.ArtId) INTO n FROM Articles WHERE Articles.ArtId = NEW.Parent;
	WHEN 2 THEN 
	    SELECT COUNT(Discussion.DiscId) INTO n FROM Discussion WHERE Discussion.DiscId = NEW.Parent;
	ELSE KILL QUERY CONNECTION_ID();
    END CASE;
    IF n=0 THEN KILL QUERY CONNECTION_ID();
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `discussion`
--

CREATE TABLE `discussion` (
  `DiscId` int(10) NOT NULL,
  `GroupId` int(10) NOT NULL,
  `UserId` int(10) NOT NULL,
  `Title` varchar(25) NOT NULL,
  `Tags` varchar(30) DEFAULT NULL,
  `DatePubl` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Дублирующая структура для представления `discussionsinfo`
-- (См. Ниже фактическое представление)
--

-- --------------------------------------------------------



-- --------------------------------------------------------

--
-- Структура таблицы `marks`
--

CREATE TABLE `marks` (
  `TypePar` tinyint(4) NOT NULL,
  `UserId` int(11) NOT NULL,
  `Parent` int(11) NOT NULL,
  `Mark` int(11) NOT NULL
) ;

--
-- Триггеры `marks`
--
DELIMITER $$
CREATE TRIGGER `addMark` BEFORE INSERT ON `marks` FOR EACH ROW BEGIN
    DECLARE n INT DEFAULT 0;
    CASE NEW.TypePar
	WHEN 0 THEN 
	    SELECT COUNT(Comments.ComId) INTO n FROM Comments WHERE Comments.ComId = NEW.Parent;
	WHEN 1 THEN 
	    SELECT COUNT(Articles.ArtId) INTO n FROM Articles WHERE Articles.ArtId = NEW.Parent;
	WHEN 2 THEN 
	    SELECT COUNT(Discussion.DiscId) INTO n FROM Discussion WHERE Discussion.DiscId = NEW.Parent;
	ELSE KILL QUERY CONNECTION_ID();
    END CASE;
    IF n=0 THEN KILL QUERY CONNECTION_ID();
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `addMarkRating` BEFORE INSERT ON `marks` FOR EACH ROW BEGIN
    DECLARE n INT DEFAULT 0;
	IF NEW.Mark = 0 THEN 
	    SELECT COUNT(Mark) INTO n FROM Marks 
	    WHERE `Parent` = NEW.Parent 
	    AND `TypePar` = NEW.TypePar 
	    AND `UserId` = NEW.UserId
	    AND `Mark` = 1;
	END IF;
	IF NEW.Mark = 1 THEN 
	    SELECT COUNT(Mark) INTO n FROM Marks 
	    WHERE `Parent` = NEW.Parent 
	    AND `TypePar` = NEW.TypePar 
	    AND `UserId` = NEW.UserId
	    AND `Mark` = 0;
	END IF;
    IF n!=0 THEN KILL QUERY CONNECTION_ID();
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------



-- --------------------------------------------------------

--
-- Структура таблицы `participation`
--

CREATE TABLE `participation` (
  `UserId` int(11) NOT NULL,
  `GroupId` int(11) NOT NULL,
  `Post` int(11) DEFAULT NULL
) ENGINE=InnoDB

--
-- Триггеры `participation`
--
DELIMITER $$
CREATE TRIGGER `addParticipation` BEFORE INSERT ON `participation` FOR EACH ROW BEGIN
    DECLARE Owner INT DEFAULT 0;
    SELECT COUNT(GroupId) INTO Owner FROM Usgroup
    WHERE OwnerId = NEW.UserId AND GroupId = NEW.GroupId;
    IF Owner!=0 THEN KILL QUERY CONNECTION_ID();
    END IF;
END
$$
DELIMITER ;




-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `UserId` int(11) NOT NULL,
  `Firstname` varchar(30) NOT NULL,
  `Surname` varchar(30) NOT NULL,
  `Nickname` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Birth` date DEFAULT NULL,
  `City` varchar(30) DEFAULT NULL,
  `Gender` tinyint(1) DEFAULT 0,
  `About` varchar(255) DEFAULT NULL,
  `Priority` int(11) NOT NULL DEFAULT 0,
  `UserPswrd` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `usgroup`
--

CREATE TABLE `usgroup` (
  `GroupId` int(11) NOT NULL,
  `OwnerId` int(11) NOT NULL,
  `Title` varchar(30) NOT NULL,
  `Theme` varchar(25) NOT NULL,
  `Description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------



-- --------------------------------------------------------

--

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `articlesinfo`  AS  select `articles`.`ArtId` AS `ArtId`,`articles`.`Name` AS `Name`,`articles`.`Description` AS `Description`,`articles`.`ArtType` AS `ArtType`,`articles`.`UserId` AS `UserId`,`users`.`Nickname` AS `Nickname`,`articles`.`Tags` AS `Tags`,`articles`.`DatePubl` AS `DatePubl`,if(`marksinfo`.`Rating` is null,0,`marksinfo`.`Rating`) AS `Rating`,`ChildComments`(`articles`.`ArtId`,1) AS `Comments` from ((`articles` join `users` on(`users`.`UserId` = `articles`.`UserId`)) left join `marksinfo` on(`marksinfo`.`Parent` = `articles`.`ArtId` and `marksinfo`.`TypePar` = 1)) ;



CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `discussionsinfo`  AS  select `discussion`.`DiscId` AS `DiscId`,`discussion`.`UserId` AS `UserId`,`discussion`.`GroupId` AS `GroupId`,`discussion`.`Title` AS `Title`,`discussion`.`Tags` AS `Tags`,`discussion`.`DatePubl` AS `DatePubl`,`usgroup`.`Title` AS `Group`,`users`.`Nickname` AS `Nickname`,if(`marksinfo`.`Rating` is null,0,`marksinfo`.`Rating`) AS `Rating` from (((`discussion` join `usgroup` on(`usgroup`.`GroupId` = `discussion`.`GroupId`)) join `users` on(`users`.`UserId` = `discussion`.`UserId`)) left join `marksinfo` on(`marksinfo`.`Parent` = `discussion`.`DiscId` and `marksinfo`.`TypePar` = 2)) ;


CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `groupsinfo`  AS  select `usgroup`.`GroupId` AS `GroupId`,`usgroup`.`Theme` AS `Theme`,`usgroup`.`Title` AS `Title`,`usgroup`.`Description` AS `Description`,`users`.`Nickname` AS `Owner`,`usgroup`.`OwnerId` AS `OwnerId`,count(`participation`.`UserId`) AS `Users`,count(`discussion`.`DiscId`) AS `Discussions` from (((`usgroup` join `users` on(`users`.`UserId` = `usgroup`.`OwnerId`)) left join `participation` on(`participation`.`GroupId` = `usgroup`.`GroupId`)) left join `discussion` on(`discussion`.`GroupId` = `usgroup`.`GroupId`)) group by `usgroup`.`GroupId` ;


CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `marksinfo`  AS  select distinct `marks`.`TypePar` AS `TypePar`,`marks`.`Parent` AS `Parent`,`getMark`(`marks`.`Parent`,`marks`.`TypePar`,0) AS `Like`,`getMark`(`marks`.`Parent`,`marks`.`TypePar`,1) AS `Dislike`,`getMark`(`marks`.`Parent`,`marks`.`TypePar`,0) - `getMark`(`marks`.`Parent`,`marks`.`TypePar`,1) AS `Rating` from `marks` ;


CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `partinfo`  AS  select `participation`.`UserId` AS `UserId`,`participation`.`GroupId` AS `GroupId`,`participation`.`Post` AS `Post`,`users`.`Nickname` AS `Nickname`,`users`.`Firstname` AS `Firstname`,`users`.`Surname` AS `Surname` from (`participation` join `users` on(`users`.`UserId` = `participation`.`UserId`)) where 1 ;


CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `search`  AS  select `sr`.`Parent` AS `Parent`,`sr`.`TypePar` AS `TypePar`,`sr`.`title` AS `Title`,`sr`.`Description` AS `Description`,`users`.`Nickname` AS `Nickname`,`sr`.`UserId` AS `UserId` from ((select 1 AS `TypePar`,`articles`.`ArtId` AS `Parent`,`articles`.`UserId` AS `UserId`,`articles`.`Description` AS `Description`,`articles`.`Name` AS `title` from `articles` union select 2 AS `TypePar`,`usgroup`.`GroupId` AS `Parent`,`usgroup`.`OwnerId` AS `UserId`,`usgroup`.`Title` AS `Title`,`usgroup`.`Description` AS `Description` from `usgroup` union select 3 AS `TypePar`,`discussion`.`DiscId` AS `Parent`,`discussion`.`UserId` AS `UserId`,`discussion`.`Title` AS `Title`,'' AS `Description` from `discussion`) `sr` join `users` on(`users`.`UserId` = `sr`.`UserId`)) ;


CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `themes`  AS  select distinct `usgroup`.`Theme` AS `Theme`,count(`usgroup`.`Theme`) AS `Pop` from `usgroup` group by `usgroup`.`Theme` order by count(`usgroup`.`Theme`) desc ;



CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewcomments`  AS  select `users`.`UserId` AS `UserId`,`users`.`Nickname` AS `Nickname`,`comments`.`ComId` AS `CommentId`,`comments`.`Textcom` AS `Text`,`comments`.`Parent` AS `Parent`,`comments`.`TypePar` AS `TypePar`,`comments`.`DatePubl` AS `DatePubl`,`ChildComments`(`comments`.`ComId`,0) AS `Nchild` from (`comments` join `users` on(`users`.`UserId` = `comments`.`UserId`)) ;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`ArtId`,`UserId`),
  ADD KEY `Article_User_FK` (`UserId`);

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`ComId`,`UserId`,`Parent`),
  ADD KEY `Comments_User` (`UserId`);

--
-- Индексы таблицы `discussion`
--
ALTER TABLE `discussion`
  ADD PRIMARY KEY (`DiscId`,`GroupId`,`UserId`),
  ADD KEY `Discussion_Group_FK` (`GroupId`),
  ADD KEY `Discussion_User_FK` (`UserId`);

--
-- Индексы таблицы `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`TypePar`,`UserId`,`Parent`,`Mark`),
  ADD KEY `Marks_User_FK` (`UserId`);

--
-- Индексы таблицы `participation`
--
ALTER TABLE `participation`
  ADD PRIMARY KEY (`UserId`,`GroupId`),
  ADD KEY `Partic_Group_FK` (`GroupId`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserId`),
  ADD UNIQUE KEY `UserId` (`UserId`),
  ADD UNIQUE KEY `Nickname` (`Nickname`),
  ADD KEY `User_login` (`Nickname`);

--
-- Индексы таблицы `usgroup`
--
ALTER TABLE `usgroup`
  ADD PRIMARY KEY (`GroupId`,`OwnerId`),
  ADD KEY `Group_Owner_FK` (`OwnerId`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `articles`
--
ALTER TABLE `articles`
  MODIFY `ArtId` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `ComId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `discussion`
--
ALTER TABLE `discussion`
  MODIFY `DiscId` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `usgroup`
--
ALTER TABLE `usgroup`
  MODIFY `GroupId` int(11) NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `Article_User_FK` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`);

--
-- Ограничения внешнего ключа таблицы `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `Comments_User` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`);

--
-- Ограничения внешнего ключа таблицы `discussion`
--
ALTER TABLE `discussion`
  ADD CONSTRAINT `Discussion_Group_FK` FOREIGN KEY (`GroupId`) REFERENCES `usgroup` (`GroupId`),
  ADD CONSTRAINT `Discussion_User_FK` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`);

--
-- Ограничения внешнего ключа таблицы `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `Marks_User_FK` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`);

--
-- Ограничения внешнего ключа таблицы `participation`
--
ALTER TABLE `participation`
  ADD CONSTRAINT `Partic_Group_FK` FOREIGN KEY (`GroupId`) REFERENCES `usgroup` (`GroupId`),
  ADD CONSTRAINT `Partic_User_FK` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`);

--
-- Ограничения внешнего ключа таблицы `usgroup`
--
ALTER TABLE `usgroup`
  ADD CONSTRAINT `Group_Owner_FK` FOREIGN KEY (`OwnerId`) REFERENCES `users` (`UserId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
